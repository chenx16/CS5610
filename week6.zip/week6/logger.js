let version = 2.6;
function log()
{
   console.log("logged successfully");
}

module.exports = {
    version,
    log,
 };